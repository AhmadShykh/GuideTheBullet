Add post process "Bloom" to make effects better like on the screenshots.
You can find it in the Asset Store or in the Package manager.
You can even create "Bloom shader" yourself :)